/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Jobs;

import java.util.List;
import java.util.Map;

/**
 *
 * @author Stephen
 */
public class lambertOptimize {  
    public static Map<String, Object> solveLambert (List<String> args) {
        return Lambert.LambertOptimizer.mainframe(args);
    }
}
