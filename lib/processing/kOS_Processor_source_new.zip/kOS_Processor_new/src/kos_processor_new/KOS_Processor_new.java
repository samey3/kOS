/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kos_processor_new;

//import static Jobs.pathFind.findPath;
//import static Jobs.optimizeLambert.solveLambert;
import Jobs.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Stephen
 */
public class KOS_Processor_new { //Main

    //Set up the path variables
    private static final String JOB_ROOT = System.getProperty("user.dir") + "\\requests\\"; //Will be in a 'processing' directory under scripts
    private static final Path JOB_REQUEST = Paths.get(JOB_ROOT + "job_request.kr");
    private static final Path JOB_READY = Paths.get(JOB_ROOT + "job_ready.kr");
    private static final Path JOB_RESULT = Paths.get(JOB_ROOT + "job_result.kr");
    private static final Path JOB_COMPLETE = Paths.get(JOB_ROOT + "job_complete.kr");
    
    public static void main(String[] args) throws InterruptedException, FileNotFoundException, IOException {
        System.out.println("Root : " + JOB_ROOT);
        
        //Keeps looping, waiting for more job requests
        while(true){
            while (!Files.exists(JOB_REQUEST) && !Files.exists(JOB_READY)) {
		Thread.sleep(100); //Perhaps switch to 10 if we're using for in-atmo updates
            }
            
            //Waits once more to ensure kOS has finished writing data
            System.out.println("Saw job request, beginning processing.");
            Thread.sleep(500); //Make sure the request file is not being written to anymore
            
            //Reads in all lines
            List<String> lines = Files.readAllLines(JOB_REQUEST);
            
            //Gets the request type and arguments
            String requestType = lines.get(0);
            List<String> requestArgs = lines.subList(1, lines.size());

            System.out.println("Received request: " + requestType);           
            String res = "";
            
            switch (requestType) {
                case "pathFind":
                    //Get the result
                   res = Utils.FormatResult.formatPathList(pathFind.findPath(requestArgs));
                    
                    //Write the result
                    try (PrintWriter writer = new PrintWriter(JOB_RESULT.toString())) {
                        writer.write(res);
                    }
            
                    //Break from case
                    break;
                case "lambertOptimize":
                    //Get the result
                    res = Utils.FormatResult.formatLambertMap(optimizeLambert.solveLambert(requestArgs));
                    
                    //Write the result
                    try (PrintWriter writer = new PrintWriter(JOB_RESULT.toString())) {
                        writer.write(res);
                    }
                    
                    //Break from case
                    break;
                default:
                    System.out.println("Unknown request type: " + requestType);
                    throw new IllegalArgumentException("Unknown request type: " + requestType);
            }
            
            //Creates the 'job complete' notification file
            try (PrintWriter pw = new PrintWriter(JOB_COMPLETE.toString())) {}
        
            //Deletes the request and ready files
            Files.delete(JOB_REQUEST);
            Files.delete(JOB_READY);
        }
    }    
}