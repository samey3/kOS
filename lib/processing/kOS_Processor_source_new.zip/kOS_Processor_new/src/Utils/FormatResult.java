/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utils;

import Objects.Node;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.math3.geometry.euclidean.threed.Vector3D;

/**
 *
 * @author Stephen
 */
public class FormatResult {    
    //Outputs the lambert solver result
    public static String formatLambertMap(Map<String, Object> map) {
        String result = "{\n\"entries\": [\n";
        Iterator it = map.entrySet().iterator();
        while (it.hasNext()) {
            //Gets the map entry
            Map.Entry<String, Object> entry = (Map.Entry<String, Object>) it.next();
            
            //Adds the entry to the result string
            result += "\"" + entry.getKey() + "\",\n";

            //If vector, apply proper formatting
            if(entry.getKey().equals("dv1") || entry.getKey().equals("dv2")){
                result += "{\n";
                result += "\"x\": " + ((Vector3D)entry.getValue()).getX() + ",\n";
                result += "\"y\": " + ((Vector3D)entry.getValue()).getY() + ",\n";
                result += "\"z\": " + ((Vector3D)entry.getValue()).getZ() + ",\n";
                result += "\"$type\": \"kOS.Suffixed.Vector\"\n";
                result += (it.hasNext() ? "},\n" : "}\n"); //If last one, do not add comma
            }
            //Else output as a string
            else {
                //result += "\"" + entry.getValue() + "\"";
                result += entry.getValue();
                result += (it.hasNext() ? ",\n" : "\n"); //If last one, do not add comma
            }
        }
        result += "],\n\"$type\": \"kOS.Safe.Encapsulation.Lexicon\"\n}";
        
        return result;
    }
    
    //Outputs the path-finding result
    public static String formatPathList(List<Node> nodeList) {
        String result = "{\n\"items\": [\n";
        for(int i = 0; i != nodeList.size(); i++){
            result += (
                "\"" 
                + nodeList.get(i).getName() 
                + (i != nodeList.size() ? "\",\n" : "\"\n")); //If last one, do not add a comma
        }
        result += "],\n \"$type\": \"kOS.Safe.Encapsulation.QueueValue\"\n }";
        
        return result;
    }
}
