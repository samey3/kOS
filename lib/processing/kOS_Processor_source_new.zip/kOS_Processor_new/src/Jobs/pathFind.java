/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Jobs;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import Objects.Graph;
import Objects.Node;
import java.awt.geom.Point2D;
import java.io.IOException;
import static java.lang.Math.abs;
import static java.lang.Math.round;
import java.nio.file.Files;
import java.nio.file.Paths;

public class pathFind {
    
    private static final String JOB_ROOT = System.getProperty("user.dir") + "\\Ships\\Script\\processing\\";
    private static final String BODY_DATA = JOB_ROOT + "body_data\\";
    
    //public static String findPath (List<String> args) throws IOException{ //List<Node>    
    public static List<Node> findPath (List<String> args) throws IOException{    
        //0 LAT IS NORTH POLE. 180 LAT IS SOUTH POLE.
        
        //-------------------------------------------------------------------------\
        //Read in request data-----------------------------------------------------|
            String body = args.get(0);
            List<String> lines = Files.readAllLines(Paths.get(BODY_DATA + body + ".txt"));
            Double precision = Double.parseDouble(lines.get(0));
                lines.remove(0);
               
        //-------------------------------------------------------------------------\
        //Find start and end coordinates-------------------------------------------|
            //Remember to toss the starting coords in the wraps incase, because in-game is -90 to 90, -180 to 180.
            Point2D start = new Point2D.Double(LTC(args.get(1), precision), LTC(args.get(2), precision)); //Lat,lng
            Point2D end = new Point2D.Double(LTC(args.get(3), precision), LTC(args.get(4), precision));
                   
        //-------------------------------------------------------------------------\
        //Create the graph---------------------------------------------------------|
            Graph graph = new Graph(precision, lines, start, end);

        //-------------------------------------------------------------------------\
        //Get shortest path from start to end--------------------------------------|
            //Get references to the start and end nodes
            Node startNode = graph.getNode(start.getX(), start.getY());
            Node endNode = graph.getNode(end.getX(), end.getY());

            //Calculate the shortest paths to all nodes
            graph.calculateShortestPathFromSource(startNode);   

            //Create the node list, add the end node
            List<Node> path = endNode.getShortestPath();
            path.add(endNode);
        
            
        return path;
    }
    
    private static double LTC (String line, double precision){        
        return round(Double.parseDouble(line)*(1/precision))/(1/precision);      
    }
}






