
package Objects;

import java.awt.geom.Point2D;
import static java.lang.Math.round;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Graph { 
    private Set<Node> nodes = new HashSet<>();
    private double precision;
    
    //Constructor
    public Graph(double precision, List<String> lines, Point2D start, Point2D end){
        
        precision = this.precision;
        
        //----------------------------------------------------------------------------------------------------------------------\
        //                                                  Variables                                                           |
        //----------------------------------------------------------------------------------------------------------------------/ 
        
            double lat_start = start.getX();
            double lng_start = start.getY();

            double lat_end = end.getX();  
            double lng_end = end.getY();

            //WLAT here should always return the passed in values.
            double lat_f = WLAT(lat_end - lat_start);
            double lat_b = WLAT(lat_start - lat_end);
            double lat_diff = Math.min(lat_f, lat_b);

            double lng_f = WLNG(lng_end - lng_start);
            double lng_b = WLNG(lng_start - lng_end);
            double lng_diff = Math.min(lng_f, lng_b);

            //If latitude difference is smaller.
            if(Math.min(lat_f, lat_b) < Math.min(lng_f, lng_b)){

            }

            double lat_step = (lat_f <= lat_b ? 1 : -1)*precision;
            double lng_step = (lng_f <= lng_b ? 1 : -1)*precision;

            double iterate_lat_start = (lat_f <= lat_b ? 0 : 180);
            //double iterate_lat_start = (lat_f <= lat_b ? 0 : lat_diff);
            double iterate_lng_start = (lng_f <= lng_b ? 0 : lng_diff);   

            double iterate_lat_end = (lat_f <= lat_b ? 180 : 0);
            //double iterate_lat_end = (lat_f <= lat_b ? lat_diff : 0);
            double iterate_lng_end = (lng_f <= lng_b ? lng_diff : 0);

            double record_lat_start = (lat_f <= lat_b ? lat_start : lat_end);
            double record_lng_start = (lng_f <= lng_b ? lng_start : lng_end);

        //----------------------------------------------------------------------------------------------------------------------\
        //                                                  Create graph                                                        |
        //----------------------------------------------------------------------------------------------------------------------/
        
            //-------------------------------------------------------------------------\
            //Create 2D-array of nodes-------------------------------------------------|
                double p_mult = (1/precision);
                Node [][] bodyGraph = new Node[(int)(182*p_mult) + 1][(int)(lng_diff*p_mult) + 1];
                //Node [][] bodyGraph = new Node[(int)(lat_diff*p_mult) + 1][(int)(lng_diff*p_mult) + 1];
                for(double i = iterate_lat_start; i != (iterate_lat_end + lat_step); i+=lat_step ){
                    for(double j = iterate_lng_start; j != (iterate_lng_end + lng_step); j+=lng_step ){
                        bodyGraph[(int)(i*p_mult)][(int)(j*p_mult)] = new Node(new Point2D.Double(i, WLNG(j+record_lng_start)), getNodeAltitude(i, WLNG(j+record_lng_start), precision, lines));
                    }
                }
                System.out.println("Created nodes.");
        
            //-------------------------------------------------------------------------\
            //Link the nodes-----------------------------------------------------------|
                for(double i = iterate_lat_start; i != (iterate_lat_end + lat_step); i+=lat_step ){
                    for(double j = iterate_lng_start; j != (iterate_lng_end + lng_step); j+=lng_step ){
                        if(i+lat_step != (iterate_lat_end + lat_step)){ //+1 lat
                            bodyGraph[(int)(i*p_mult)][(int)(j*p_mult)].addDestination(bodyGraph[(int)((i+lat_step)*p_mult)][(int)(j*p_mult)]); }
                        if(i-lat_step != (iterate_lat_start - lat_step)){ //-1 lat
                            bodyGraph[(int)(i*p_mult)][(int)(j*p_mult)].addDestination(bodyGraph[(int)((i-lat_step)*p_mult)][(int)(j*p_mult)]); }
                        if(j+lng_step != (iterate_lng_end + lng_step)){ //+1 lng
                            bodyGraph[(int)(i*p_mult)][(int)(j*p_mult)].addDestination(bodyGraph[(int)(i*p_mult)][(int)((j+lng_step)*p_mult)]); }
                        if((i+lat_step != (iterate_lat_end + lat_step)) && (j+lng_step != (iterate_lng_end + lng_step))){ //+1 lat +1 lng
                            bodyGraph[(int)(i*p_mult)][(int)(j*p_mult)].addDestination(bodyGraph[(int)((i+lat_step)*p_mult)][(int)((j+lng_step)*p_mult)]); }
                        if((i-lat_step != (iterate_lat_start - lat_step)) && (j+lng_step != (iterate_lng_end + lng_step))){ //-1 lat +1 lng
                            bodyGraph[(int)(i*p_mult)][(int)(j*p_mult)].addDestination(bodyGraph[(int)((i-lat_step)*p_mult)][(int)((j+lng_step)*p_mult)]); }
                    }
                }
                System.out.println("Linked nodes.");
        
            //-------------------------------------------------------------------------\
            //Add the nodes------------------------------------------------------------|
                for(double i = iterate_lat_start; i != (iterate_lat_end + lat_step); i+=lat_step ){
                    for(double j = iterate_lng_start; j != (iterate_lng_end + lng_step); j+=lng_step ){
                        this.addNode(bodyGraph[(int)(i*p_mult)][(int)(j*p_mult)]);
                    }
                }        
                System.out.println("Added nodes to graph.\n");
    }

    
    //----------------------------------------------------------------------------------------------------------------------\
    //                                                 Public functions                                                     |
    //----------------------------------------------------------------------------------------------------------------------/
    
    
        public void addNode(Node nodeA) {
            nodes.add(nodeA);
        }
        
        public Node getNode(Node node){
            String name = node.getName();
            Object[] nodeArray = nodes.toArray();
            for (int i = 0; i < nodeArray.length; i++) {
                if(((Node)nodeArray[i]).getName() == name){
                    return ((Node)nodeArray[i]);
                }
            }
            return null;
        }

        public Node getNode(double lat, double lng){
            String name = (lat + "_" + lng);
            Object[] nodeArray = nodes.toArray();
            for (int i = 0; i < nodeArray.length; i++) {
                if(((Node)nodeArray[i]).getName() == name){
                    return ((Node)nodeArray[i]);
                }
            }
            return null;
        }

         public static void calculateShortestPathFromSource(Node source) {
            source.setDistance(0.0);

            Set<Node> settledNodes = new HashSet<>();
            Set<Node> unsettledNodes = new HashSet<>();

            unsettledNodes.add(source);

            while (unsettledNodes.size() != 0) {
                //System.out.println("Nodes left : " + unsettledNodes.size());
                Node currentNode = getLowestDistanceNode(unsettledNodes);
                unsettledNodes.remove(currentNode);
                for (Map.Entry < Node, Double> adjacencyPair: 
                  currentNode.getAdjacentNodes().entrySet()) {
                    Node adjacentNode = adjacencyPair.getKey();
                    Double edgeWeight = adjacencyPair.getValue();
                    if (!settledNodes.contains(adjacentNode)) {
                        CalculateMinimumDistance(adjacentNode, edgeWeight, currentNode);
                        unsettledNodes.add(adjacentNode);
                    }
                }
                settledNodes.add(currentNode);
            }
        }
    

    //----------------------------------------------------------------------------------------------------------------------\
    //                                                 Private functions                                                    |
    //----------------------------------------------------------------------------------------------------------------------/
     
     
        private static double WLAT(double coordinate) {
            if(coordinate < 0) return (360 + coordinate);
            else if (coordinate > 180) return (coordinate - 360);
            else return coordinate;
        }

        private static double WLNG(double coordinate) {
            if(coordinate < 0) return (360 + coordinate);
            else if (coordinate > 360) return (coordinate - 360);
            else return coordinate;
        }

        private static double getNodeAltitude(double lat, double lng, double precision, List<String> lines){
            double p_mult = (1/precision);
            //The squared makes sense, but why +2? 1 for precision, why the other?
            int index = (int)(lat*360*Math.pow(p_mult, 2) + lng*p_mult + 2) ; //*360 because 360 lngs for every lat
            //int index = (int)(lat*360*Math.pow(p_mult, 2) + lng*p_mult); //*360 because 360 lngs for every lat
            return Double.parseDouble(lines.get(index));
        }

        private static Node getLowestDistanceNode(Set < Node > unsettledNodes) {
            Node lowestDistanceNode = null;
            double lowestDistance = Double.MAX_VALUE;
            for (Node node: unsettledNodes) {
                double nodeDistance = node.getDistance();
                if (nodeDistance < lowestDistance) {
                    lowestDistance = nodeDistance;
                    lowestDistanceNode = node;
                }
            }
            return lowestDistanceNode;
        }

        private static void CalculateMinimumDistance(Node evaluationNode,
            Double edgeWeigh, Node sourceNode) {
            Double sourceDistance = sourceNode.getDistance();
            if (sourceDistance + edgeWeigh < evaluationNode.getDistance()) {
                evaluationNode.setDistance(sourceDistance + edgeWeigh);
                LinkedList<Node> shortestPath = new LinkedList<>(sourceNode.getShortestPath());
                shortestPath.add(sourceNode);
                evaluationNode.setShortestPath(shortestPath);
            }
        }
}
