package Objects;

public class Body {
	private String _name;
	private double _mu;
        private double _radius;
        private double _atmoHeight;

	public Body(String name, double mu, double radius, double atmoHeight) {
            _name = name;
            _mu = mu;
            _radius = radius;
            _atmoHeight = atmoHeight;
	}

	public String getName() {
		return _name;
	}

	public double getMu() {
		return _mu;
	}
        
        public double getRadius(){
            return _radius;
        }
        
        public double getAtmoHeight(){
            return _atmoHeight;
        }
}